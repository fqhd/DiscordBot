If you are using BungeeCord make sure to upload FakePlayers.jar to all your
spigot servers and FakePlayers (BungeeCord).jar into your BungeeCord's plugin
folder. Make sure to enable bungeecord in config.yml and set up FakePlayers
Socket's ports correctly. All of them need to be different if you are hosting
all servers on the same machine. If that's not the case, you can set every single
one of them to 5721.